


Pour pouvoir lancer l'application : modifier :
	dans Classe model.orm.LogToDatabase
		ajuster les valeurs des champs user et passwd pour votre groupe

Sinon l'application démarrera mais se mettra en erreur au premier accès à la base de données.

Il faudra aussi jouer le script de création de la BD.